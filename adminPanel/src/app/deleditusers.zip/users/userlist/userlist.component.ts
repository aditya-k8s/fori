import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormGroup } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DataService } from '../../data.service';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {


  userslist : any = []; 
  isLoading : boolean = false; 
  isRecord : boolean = false;
  searchStr: string = ""; 
  isDelete : boolean = false;
  users_id : any = "";
  index : any;
  constructor(
  	private dataService: DataService,
  	public toastr : ToastrManager) {
  	 }

  ngOnInit() {

	this.getUser();
  }

getUser(){
	this.users_id = sessionStorage.getItem('user_id');

	this.dataService.getUsers(this.users_id).subscribe(response => {
		//console.log(response,'-----')
	    if(response['success'] == true){
	    	this.userslist = response['body'];
	    	console.log(this.userslist,'-----')
	   	}
	});
}


openDelete(pvarIndex:any,pvarId:any){  
    this.index = pvarIndex
    this.users_id = pvarId;
    this.isDelete = true;
    if(confirm("Are you sure to delete ")) {
      console.log(this.users_id);
      this.dataService.deleteUser(this.users_id).subscribe(response =>{
      if(response['success'] == true){
        this.toastr.successToastr(response['message']);
        this.userslist = [];
        this.getUser();
        //this.userslist.splice(this.userslist.indexOf(this.index), 1);
        this.isDelete = false;
      }else{
        console.log(response['message']);
      }
    },error =>{
        console.log(error);
  })
  }else{
    console.log('no');
  }
}


updateUserStatus(users_id:any){
    this.dataService.updateUserStatus(users_id).subscribe(response =>{
      if(response['success'] == true){
        this.toastr.successToastr(response['message']);
        this.userslist = [];
        this.getUser();
        //this.userslist.splice(this.userslist.indexOf(this.index), 1);
        this.isDelete = false;
      }else{
        console.log(response['message']);
      }
    },error =>{
        console.log(error);
  })
}
hideModel(){ this.isDelete = false; }

// openProfit(pvarId){
//   this.router.navigate(['/user-profit-report'], { queryParams: { id: pvarId } });
// }

}

