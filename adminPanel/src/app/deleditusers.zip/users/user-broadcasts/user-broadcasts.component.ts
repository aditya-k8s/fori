import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-broadcasts',
  templateUrl: './user-broadcasts.component.html',
  styleUrls: ['./user-broadcasts.component.css']
})
export class UserBroadcastsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
