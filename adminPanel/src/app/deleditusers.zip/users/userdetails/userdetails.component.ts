import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormGroup } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DataService } from '../../data.service';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {


  userslist : any = []; 
  isLoading : boolean = false; 
  isRecord : boolean = false;
  searchStr: string = ""; 
  channelName : any ="";
  users_id : any = "";
  index : any;
  constructor(
  	private dataService: DataService,
  	public toastr : ToastrManager,
  	private router: Router,
  	private route: ActivatedRoute) {
  		this.route.params.forEach((params: Params) => {
      		this.channelName = params['channelName'];
      		console.log(this.channelName);
    	})
  	 }

  ngOnInit() {

	this.usersDetails();
  }


usersDetails(){

	this.dataService.usersDetails(this.channelName).subscribe(response => {
		//console.log(response,'-----')
	    if(response['success'] == true){
	    	this.userslist = response['body'];
	    	console.log(this.userslist,'-----')
	   	}
	});
}




}

